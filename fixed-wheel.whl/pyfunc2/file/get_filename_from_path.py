import os

def get_filename_from_path(filepath):
    return os.path.basename(filepath)

