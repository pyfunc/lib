def check_existing_folder_list_in_path():
    return True